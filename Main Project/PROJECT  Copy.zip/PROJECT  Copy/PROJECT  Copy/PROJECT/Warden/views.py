from django.shortcuts import render
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm 
from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import  SemesterOneForm,FeedForm,BbaOneForm
from Main.models import SemesterOne,BbaOne

# Create your views here.

def wardenhome(request):
    return render(request, "Warden/homepage.html",{})

def oneinput(request):
    return render(request, "Warden/oneinput.html",{})

def bbaoneinput(request):
      return render(request, "Warden/bbaoneinput.html",{})

def SemesterOne_Result(request):
    if request.method == 'POST':
        student = SemesterOne.objects.get(Regdno=request.POST.get('regdno'))
        form = SemesterOneForm()
        return render(request,"Warden/semesteroneresult.html", {'student':student,'form':form})
    return render(request,"Warden/oneinput.html")

def onesave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = SemesterOne.objects.get(Regdno = Regdno)
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request,"Main/oneinput.html",{'form':form})

def get_resultbbaone(request):
      if request.method == 'POST':
         student = BbaOne.objects.get(Regdno = request.POST.get('regdno'))
         form = BbaOneForm()
         return render(request, "Warden/onebba.html",{'student':student,'form':form})
      return render(request, "Warden/bbaoneinput.html")

def bbaonesave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = BbaOne.objects.get(Regdno = Regdno)
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request, "Warden/bbaoneinput.html",{'form':form})