from django import forms
from Main.models import Students,Stu,Subject,SemesterOne,SemesterTwo,Student,SemesterThree,SemesterFour,SemesterSix,MscFour,MscOne,MscThree,MscTwo,BbaOne,BbaTwo
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class FeedForm(forms.ModelForm):
    class Meta:
        model = Students
        fields = ['Warden']
        widgets = {
        #   'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
          'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
        }

class SemesterOneForm(forms.ModelForm):
      class Meta:
            model = SemesterOne
            fields = ['Warden']
            widgets = {
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class BbaOneForm(forms.ModelForm):
      class Meta:
            model = BbaOne
            fields = ['Warden']
            widgets = {
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }
