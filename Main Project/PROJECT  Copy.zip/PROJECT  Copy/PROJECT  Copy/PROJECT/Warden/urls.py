from django.urls import path
from django.views import View
from . import views

urlpatterns = [
    path("wardenhome/",views.wardenhome,name="wardenhome"),
    path("wardenhome/woneinput/",views.oneinput,name="oneinput"),
    path("oneresult/",views.SemesterOne_Result,name="wor"),
    path("onesave/<str:Regdno>/",views.onesave,name="wos"),
    path("wardenhome/wbbaoneinput/",views.bbaoneinput,name="wbbaoneinput"),
    path("wbbaoneresult/",views.get_resultbbaone,name="wbor"),
    path("bbaonesave/<str:Regdno>/",views.bbaonesave,name="wbos"),
]