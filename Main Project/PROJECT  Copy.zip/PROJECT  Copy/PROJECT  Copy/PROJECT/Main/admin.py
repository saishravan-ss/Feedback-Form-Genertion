from django.contrib import admin
from .models import Student,BbaThree,BbaFive,Students,Stu,SemesterOne,SemesterFour,SemesterSix,SemesterThree,SemesterTwo,MscFour,MscOne,MscThree,MscTwo,BbaOne,BbaTwo
from import_export.admin import ExportActionMixin, ImportExportModelAdmin

# Register your models here.

admin.site.register(Student)
admin.site.register(Students)
admin.site.register(Stu)

admin.site.register(SemesterTwo)
admin.site.register(SemesterFour)
admin.site.register(SemesterThree)
admin.site.register(SemesterSix)
admin.site.register(MscTwo)
admin.site.register(MscFour)
admin.site.register(MscThree)
admin.site.register(MscOne)
admin.site.register(BbaOne)
admin.site.register(BbaTwo)
admin.site.register(BbaThree)
admin.site.register(BbaFive)


class SemesterOneAdmin(ExportActionMixin, admin.ModelAdmin):
    list_display = ('Regdno','Name','Class','UCSH_101','UCSH_102','UCSH_103','UCSH_104','UCSH_105','UCSH_101_70','UCSH_102_70','UCSH_103_70','UCSH_104_70','UCSH_105_70')


@admin.register(SemesterOne)
class ViewAdmin(ImportExportModelAdmin):
    pass