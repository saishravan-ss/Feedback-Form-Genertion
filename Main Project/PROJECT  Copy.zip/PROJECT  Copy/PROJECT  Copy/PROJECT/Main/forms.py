from django import forms
from .models import Students,Stu,Subject,BbaThree,BbaFive,SemesterOne,SemesterTwo,Student,SemesterThree,SemesterFour,SemesterSix,MscFour,MscOne,MscThree,MscTwo,BbaOne,BbaTwo
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class ExcelUploadForm(forms.Form):
    excel_file = forms.FileField()


class SearchForm(forms.Form):
    Regdno = forms.CharField()

class FeedForm(forms.ModelForm):
    class Meta:
        model = Students
        fields = ['Faculty','Warden']
        widgets = {
          'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
          'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
        }

class SemesterOneForm(forms.ModelForm):
      class Meta:
            model = SemesterOne
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }
       
class SemesterTwoForm(forms.ModelForm):
      class Meta:
            model = SemesterTwo
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class SemesterThreeForm(forms.ModelForm):
      class Meta:
            model = SemesterThree
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class SemesterFourForm(forms.ModelForm):
      class Meta:
            model = SemesterFour
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }
class SemesterSixForm(forms.ModelForm):
      class Meta:
            model = SemesterSix
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class MscOneForm(forms.ModelForm):
      class Meta:
            model = MscOne
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class MscTwoForm(forms.ModelForm):
      class Meta:
            model = MscTwo
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class MscThreeForm(forms.ModelForm):
      class Meta:
            model = MscThree
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class MscFourForm(forms.ModelForm):
      class Meta:
            model = MscFour
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class BbaOneForm(forms.ModelForm):
      class Meta:
            model = BbaOne
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class BbaTwoForm(forms.ModelForm):
      class Meta:
            model = BbaTwo
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class BbaThreeForm(forms.ModelForm):
      class Meta:
            model = BbaThree
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class BbaFiveForm(forms.ModelForm):
      class Meta:
            model = BbaFive
            fields = ['Faculty','Warden']
            widgets = {
                  'Faculty': forms.Textarea(attrs={'rows':5, 'cols':50}),
                  'Warden': forms.Textarea(attrs={'rows':5, 'cols':50}),
            }

class NewUserForm(UserCreationForm):
	email = forms.EmailField(required=True)

	class Meta:
		model = User
		fields = ("username", "email", "password1", "password2")

	def save(self, commit=True):
		user = super(NewUserForm, self).save(commit=False)
		user.email = self.cleaned_data['email']
		if commit:
			user.save()
		return user
      
class StudentForm(forms.ModelForm):
      class Meta:
            model = Student
            exclude = ['Subjects'] 

class SubjectForm(forms.Form):
      pass


class SemesterForm(forms.Form):
      semester_choices = [('1','1st Semester'),('2','2nd Semester'),('2','2nd Semester'),('3','3rd Semester'),('4','4th Semester'),('5','5th Semester'),('6','6th Semester'),]
      semester = forms.ChoiceField(choices = semester_choices, widget=forms.RadioSelect)
      
class StuForm(forms.ModelForm):
    class Meta:
        model = Stu
        fields = ['regdno', 'name', 'Class', 'marks', 'feedF', 'feedW']

    subject_codes = forms.MultipleChoiceField(choices=[], widget=forms.CheckboxSelectMultiple)

    def __init__(self, *args, **kwargs):
        subject_codes = kwargs.pop('subject_codes', [])
        super().__init__(*args, **kwargs)
        self.fields['subject_codes'].choices = [(code, code) for code in subject_codes]