from django.db import models

# Create your models here.

class Student(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    SEMESTERS = (
        (1,'Semester 1'),
        (2,'Semester 2'),
        (3,'Semester 3'),
        (4,'Semester 4'),
        (5,'Semester 5'),
        (6,'Semester 6'),
    )
    Semester = models.IntegerField(default=0, choices=SEMESTERS)
    Subjects = models.CharField(default=0,max_length=1024)
    feedF = models.TextField(default='',blank=True)
    feedW = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno
    
class Students(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UCSH_501 = models.IntegerField(default=0,blank=True)
    UCSH_502 = models.IntegerField(default=0,blank=True)
    UCSH_503 = models.IntegerField(default=0,blank=True)
    UCSH_504 = models.IntegerField(default=0,blank=True)
    UCSH_505 = models.IntegerField(default=0,blank=True)
    UCSH_506 = models.IntegerField(default=0,blank=True)
    UCSH_507 = models.IntegerField(default=0,blank=True)
    UCSH_501_70 = models.IntegerField(default=0,blank=True)
    UCSH_502_70 = models.IntegerField(default=0,blank=True)
    UCSH_503_70 = models.IntegerField(default=0,blank=True)
    UCSH_504_70 = models.IntegerField(default=0,blank=True)
    UCSH_505_70 = models.IntegerField(default=0,blank=True)
    UCSH_506_70 = models.IntegerField(default=0,blank=True)
    UCSH_507_70 = models.IntegerField(default=0,blank=True)

    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno
    
class SemesterOne(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UCSH_101 = models.IntegerField(default=0,blank=True)
    UDS_101 = models.IntegerField(default=0,blank=True)
    UCSH_102 = models.IntegerField(default=0,blank=True)
    SEC_100 = models.IntegerField(default=0,blank=True)
    UCSH_101_70 = models.IntegerField(default=0,blank=True)
    UDS_101_70 = models.IntegerField(default=0,blank=True)
    UCSH_102_70 = models.IntegerField(default=0,blank=True)
    SEC_100_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno

class BbaOne(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UBBA_101 = models.IntegerField(default=0,blank=True)
    UBBA_102 = models.IntegerField(default=0,blank=True)
    UBBA_103 = models.IntegerField(default=0,blank=True)
    UBBA_104 = models.IntegerField(default=0,blank=True)
    UBBA_101_70 = models.IntegerField(default=0,blank=True)
    UBBA_102_70 = models.IntegerField(default=0,blank=True)
    UBBA_103_70 = models.IntegerField(default=0,blank=True)
    UBBA_104_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno
    
class BbaThree(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UBBA_301 = models.IntegerField(default=0,blank=True)
    UBBA_302 = models.IntegerField(default=0,blank=True)
    UBBA_303 = models.IntegerField(default=0,blank=True)
    UBBA_304 = models.IntegerField(default=0,blank=True)
    UBBA_301_70 = models.IntegerField(default=0,blank=True)
    UBBA_302_70 = models.IntegerField(default=0,blank=True)
    UBBA_303_70 = models.IntegerField(default=0,blank=True)
    UBBA_304_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno

class BbaFive(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UBBA_501 = models.IntegerField(default=0,blank=True)
    UBBA_502 = models.IntegerField(default=0,blank=True)
    UBBA_503 = models.IntegerField(default=0,blank=True)
    UBBA_504 = models.IntegerField(default=0,blank=True)
    UBBA_505 = models.IntegerField(default=0,blank=True)
    UBBA_506 = models.IntegerField(default=0,blank=True)
    UBBA_501_70 = models.IntegerField(default=0,blank=True)
    UBBA_502_70 = models.IntegerField(default=0,blank=True)
    UBBA_503_70 = models.IntegerField(default=0,blank=True)
    UBBA_504_70 = models.IntegerField(default=0,blank=True)
    UBBA_505_70 = models.IntegerField(default=0,blank=True)
    UBBA_506_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

class SemesterTwo(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UCSH_201 = models.IntegerField(default=0,blank=True)
    UCSH_202 = models.IntegerField(default=0,blank=True)
    UCSH_203 = models.IntegerField(default=0,blank=True)
    UCSH_204 = models.IntegerField(default=0,blank=True)
    UCSH_205 = models.IntegerField(default=0,blank=True)
    UCSH_201_70 = models.IntegerField(default=0,blank=True)
    UCSH_202_70 = models.IntegerField(default=0,blank=True)
    UCSH_203_70 = models.IntegerField(default=0,blank=True)
    UCSH_204_70 = models.IntegerField(default=0,blank=True)
    UCSH_205_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno
    
class BbaTwo(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UBBA_201 = models.IntegerField(default=0,blank=True)
    UBBA_202 = models.IntegerField(default=0,blank=True)
    UBBA_203 = models.IntegerField(default=0,blank=True)
    UBBA_204 = models.IntegerField(default=0,blank=True)
    UBBA_205 = models.IntegerField(default=0,blank=True)
    UBBA_201_70 = models.IntegerField(default=0,blank=True)
    UBBA_202_70 = models.IntegerField(default=0,blank=True)
    UBBA_203_70 = models.IntegerField(default=0,blank=True)
    UBBA_204_70 = models.IntegerField(default=0,blank=True)
    UBBA_205_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno
    
class SemesterThree(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UCSH_301 = models.IntegerField(default=0,blank=True)
    UCSH_302 = models.IntegerField(default=0,blank=True)
    UCSH_303 = models.IntegerField(default=0,blank=True)
    UCSH_304 = models.IntegerField(default=0,blank=True)
    UCSH_301_70 = models.IntegerField(default=0,blank=True)
    UCSH_302_70 = models.IntegerField(default=0,blank=True)
    UCSH_303_70 = models.IntegerField(default=0,blank=True)
    UCSH_304_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno

class SemesterFour(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UCSH_401 = models.IntegerField(default=0,blank=True)
    UCSH_402 = models.IntegerField(default=0,blank=True)
    UCSH_403 = models.IntegerField(default=0,blank=True)
    UCSH_404 = models.IntegerField(default=0,blank=True)
    UCSH_405 = models.IntegerField(default=0,blank=True)
    UCSH_401_70 = models.IntegerField(default=0,blank=True)
    UCSH_402_70 = models.IntegerField(default=0,blank=True)
    UCSH_403_70 = models.IntegerField(default=0,blank=True)
    UCSH_404_70 = models.IntegerField(default=0,blank=True)
    UCSH_405_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno
    
class SemesterSix(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    UCSH_601 = models.IntegerField(default=0,blank=True)
    UCSH_602 = models.IntegerField(default=0,blank=True)
    UCSH_603 = models.IntegerField(default=0,blank=True)
    UCSH_604 = models.IntegerField(default=0,blank=True)
    UCSH_605 = models.IntegerField(default=0,blank=True)
    UCSH_601_70 = models.IntegerField(default=0,blank=True)
    UCSH_602_70 = models.IntegerField(default=0,blank=True)
    UCSH_603_70 = models.IntegerField(default=0,blank=True)
    UCSH_604_70 = models.IntegerField(default=0,blank=True)
    UCSH_605_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno

class MscOne(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    MDSC_101 = models.IntegerField(default=0,blank=True)
    MDSC_102 = models.IntegerField(default=0,blank=True)
    MDSC_103 = models.IntegerField(default=0,blank=True)
    MDSC_104 = models.IntegerField(default=0,blank=True)
    MDSC_105 = models.IntegerField(default=0,blank=True)
    MDSC_101_70 = models.IntegerField(default=0,blank=True)
    MDSC_102_70 = models.IntegerField(default=0,blank=True)
    MDSC_103_70 = models.IntegerField(default=0,blank=True)
    MDSC_104_70 = models.IntegerField(default=0,blank=True)
    MDSC_105_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno

class MscTwo(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    MDSC_201 = models.IntegerField(default=0,blank=True)
    MDSC_202 = models.IntegerField(default=0,blank=True)
    MDSC_203 = models.IntegerField(default=0,blank=True)
    MDSC_204 = models.IntegerField(default=0,blank=True)
    MDSC_205 = models.IntegerField(default=0,blank=True)
    MDSC_201_70 = models.IntegerField(default=0,blank=True)
    MDSC_202_70 = models.IntegerField(default=0,blank=True)
    MDSC_203_70 = models.IntegerField(default=0,blank=True)
    MDSC_204_70 = models.IntegerField(default=0,blank=True)
    MDSC_205_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno

class MscThree(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    MDSC_301 = models.IntegerField(default=0,blank=True)
    MDSC_302 = models.IntegerField(default=0,blank=True)
    MDSC_303 = models.IntegerField(default=0,blank=True)
    MDSC_304 = models.IntegerField(default=0,blank=True)
    MDSC_301_70 = models.IntegerField(default=0,blank=True)
    MDSC_302_70 = models.IntegerField(default=0,blank=True)
    MDSC_303_70 = models.IntegerField(default=0,blank=True)
    MDSC_304_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno
    
class MscFour(models.Model):
    Regdno = models.CharField(primary_key=True, max_length=10)
    Name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    MDSC_401 = models.IntegerField(default=0,blank=True)
    MDSC_402 = models.IntegerField(default=0,blank=True)
    MDSC_403 = models.IntegerField(default=0,blank=True)
    MDSC_404 = models.IntegerField(default=0,blank=True)
    MDSC_405 = models.IntegerField(default=0,blank=True)
    MDSC_401_70 = models.IntegerField(default=0,blank=True)
    MDSC_402_70 = models.IntegerField(default=0,blank=True)
    MDSC_403_70 = models.IntegerField(default=0,blank=True)
    MDSC_404_70 = models.IntegerField(default=0,blank=True)
    MDSC_405_70 = models.IntegerField(default=0,blank=True)
    Faculty = models.TextField(default='',blank=True)
    Warden = models.TextField(default='',blank=True)

    def __str__(self):
        return self.Regdno

class Stu(models.Model):
    regdno = models.CharField(max_length=10, primary_key=True)
    name = models.CharField(max_length=100)
    Class = models.CharField(max_length=20)
    marks = models.IntegerField()
    feedF = models.BooleanField(default=False)
    feedW = models.BooleanField(default=False)
    semester = models.CharField(max_length=10)

class Subject(models.Model):
    code = models.CharField(max_length=10, primary_key=True)
    name = models.CharField(max_length=100)
    semester = models.CharField(max_length=10)

