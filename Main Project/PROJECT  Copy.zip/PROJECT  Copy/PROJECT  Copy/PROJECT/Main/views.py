from django import forms
from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import FeedForm, NewUserForm,BbaThreeForm,BbaFiveForm, StuForm,StudentForm, SemesterOneForm, SemesterTwoForm, SemesterThreeForm, SemesterFourForm,SemesterSixForm,MscOneForm,MscFourForm,MscThreeForm,MscTwoForm,BbaOneForm,BbaTwoForm
from .models import Student,Students,BbaFive,BbaThree,SemesterOne,SemesterTwo,SemesterThree,SemesterFour,SemesterSix,MscOne,MscTwo,MscThree,MscFour,BbaOne,BbaTwo
from django.http import HttpResponseRedirect
import pandas as pd
from django.contrib import messages
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm 
import json #add this

# Create your views here.

def homepage(request):
      return render(request, "Main/homepage.html", {})

def logoutpage(request):
      return render(request, "Main/logoutpage.html", {})
    
def registersuccess(request):
      return render(request, "Main/registersuccess.html",{})

def input(request):
    return render(request, "Main/input.html",{})

def twoinput(request):
      return render(request, "Main/twoinput.html",{})

def semesteroneupload(request):
    return render(request, "Main/semesteroneupload", {})

def oneinput(request):
    return render(request, "Main/oneinput.html",{})

def threeinput(request):
    return render(request, "Main/threeinput.html",{})

def fourinput(request):
    return render(request, "Main/fourinput.html",{})

def sixinput(request):
    return render(request,"Main/sixinput.html",{})

def moneinput(request):
    return render(request, "Main/moneinput.html",{})

def msctwoinput(request):
    return render(request, "Main/msctwoinput.html",{})

def mscthreeinput(request):
    return render(request, "Main/mscthreeinput.html",{})

def mscfourinput(request):
    return render(request, "Main/mscfourinput.html",{})

def bbaoneinput(request):
      return render(request, "Main/bbaoneinput.html",{})

def bbatwoinput(request):
      return render(request, "Main/bbatwoinput.html",{})

def bbathreeinput(request):
      return render(request, "Main/bbathreeinput.html",{})

def bbafiveinput(request):
      return render(request, "Main/bbafiveinput.html",{})

def get_result(request):
    if request.method == 'POST':
        student=Students.objects.get(Regdno=request.POST.get('regdno'))
        form=FeedForm()
        return render(request,"Main/result.html",{'student':student,'form':form})
    return render(request, "Main/input.html") 

def SemesterOne_Result(request):
    if request.method == 'POST':
        student = SemesterOne.objects.get(Regdno=request.POST.get('regdno'))
        form = SemesterOneForm()
        return render(request,"Main/semesteroneresult.html", {'student':student,'form':form})
    return render(request,"Main/oneinput.html")

def get_resulttwo(request):
    if request.method == 'POST':
       student = SemesterTwo.objects.get(Regdno=request.POST.get('regdno'))
       form=SemesterTwoForm()
       return render(request, "Main/SemesterTwoResult.html",{'student':student,'form':form})
    return render(request,"Main/twoinput.html")

def get_resultthree(request):
    if request.method == 'POST':
           student = SemesterThree.objects.get(Regdno=request.POST.get('regdno'))
           form = SemesterThreeForm()
           return render(request, "Main/SemesterThreeresult.html",{'student':student,'form':form})
    return render(request, "Main/threeinput.html")

def get_resultfour(request):
    if request.method == 'POST':
           student = SemesterFour.objects.get(Regdno=request.POST.get('regdno'))
           form = SemesterFourForm()
           return render(request, "Main/SemesterFourResult.html",{'student':student,'form':form})
    return render(request, "Main/fourinput.html")

def get_resultsix(request):
    if request.method == 'POST':
           student = SemesterSix.objects.get(Regdno=request.POST.get('regdno'))
           form = SemesterSixForm()
           return render(request, "Main/SemesterSixResult.html",{'student':student,'form':form})
    return render(request, "Main/sixinput.html")

def get_resultmone(request):
    if request.method == 'POST':
        student = MscOne.objects.get(Regdno=request.POST.get('regdno'))
        form = MscOneForm()
        return render(request, "Main/msconeresult.html",{'student':student,'form':form})
    return render(request, "Main/moneinput.html")
        

def get_resultmtwo(request):
    if request.method == 'POST':
        student = MscTwo.objects.get(Regdno=request.POST.get('regdno'))
        form = MscTwoForm()
        return render(request, "Main/msctworesult.html",{'student':student,'form':form})
    return render(request, "Main/msctwoinput.html")

def get_resultmthree(request):
    if request.method == 'POST':
        student = MscThree.objects.get(Regdno=request.POST.get('regdno'))
        form = MscThreeForm()
        return render(request, "Main/mscthreeresult.html",{'student':student,'form':form})
    return render(request, "Main/mscthreeinput.html")

def get_resultmfour(request):
    if request.method == 'POST':
        student = MscFour.objects.get(Regdno=request.POST.get('regdno'))
        form = MscFourForm()
        return render(request, "Main/mscfourresult.html",{'student':student,'form':form})
    return render(request, "Main/mscfourinput.html")

def get_resultbbaone(request):
      if request.method == 'POST':
         student = BbaOne.objects.get(Regdno = request.POST.get('regdno'))
         form = BbaOneForm()
         return render(request, "Main/onebba.html",{'student':student,'form':form})
      return render(request, "Main/bbaoneinput.html")

def get_resultbbatwo(request):
      if request.method == 'POST':
         student = BbaTwo.objects.get(Regdno = request.POST.get('regdno'))
         form = BbaTwoForm()
         return render(request, "Main/twobba.html",{'student':student,'form':form})
      return render(request, "Main/bbatwoinput.html")

def get_resultbbathree(request):
      if request.method == 'POST':
         student = BbaThree.objects.get(Regdno = request.POST.get('regdno'))
         form = BbaThreeForm()
         return render(request, "Main/threebba.html",{'student':student,'form':form})
      return render(request, "Main/bbathreeinput.html")

def get_resultbbafive(request):
      if request.method == 'POST':
         student = BbaFive.objects.get(Regdno = request.POST.get('regdno'))
         form = BbaFiveForm()
         return render(request, "Main/fivebba.html",{'student':student,'form':form})
      return render(request, "Main/bbafiveinput.html")

def save(request,Regdno):
    if request.method =='POST':
        form = FeedForm(request.POST)
        student=Students.objects.get(Regdno=Regdno)
        student.feedW=request.POST.get('feedW')
        student.feedF=request.POST.get('feedF')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
        form = FeedForm()
    return render(request, "Main/input.html", {'form':form})

def foursave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = SemesterFour.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request,"Main/fourinput.html",{'form':form})

def onesave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = SemesterOne.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request,"Main/oneinput.html",{'form':form})

def twosave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = SemesterTwo.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request,"Main/twoinput.html",{'form':form})

def threesave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = SemesterThree.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request,"Main/threeinput.html",{'form':form})

def sixsave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = SemesterSix.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request,"Main/sixinput.html",{'form':form})

def msconesave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = MscOne.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request, "Main/moneinput.html",{'form':form})


def msctwosave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = MscTwo.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request, "Main/msctwoinput.html",{'form':form})

def mscthreesave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = MscThree.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request, "Main/mscthreeinput.html",{'form':form})

def mscfoursave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = MscFour.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request, "Main/mscfourinput.html",{'form':form})

def bbaonesave(request,Regdno):
    if request.method == 'POST':
        form = FeedForm(request.POST)
        student = BbaOne.objects.get(Regdno = Regdno)
        student.Faculty = request.POST.get('Faculty')
        student.Warden = request.POST.get('Warden')
        student.save()
        return render(request, "Main/savesuccess.html")
    else:
          form = FeedForm()
    return render(request, "Main/bbaoneinput.html",{'form':form})

def upload_excel(request):
      if request.method == 'POST' and request.FILES['excel_file']:
         excel_file = request.FILES['excel_file']
         df = pd.read_excel(excel_file, sheet_name=None)
         for sheet_name in df:
            if sheet_name == 'SemesterOne':
                    for index, row in df[sheet_name].iterrows():
                          model_instance = SemesterOne()
                          model_instance.Regdno = row['Regdno']
                          model_instance.Name = row['Name']
                          model_instance.Class = row['Class']
                          model_instance.UCSH_101 = row['UCSH_101']
                          model_instance.UCSH_102 = row['UCSH_102']
                          model_instance.UCSH_103 = row['UCSH_103']
                          model_instance.UCSH_104 = row['UCSH_104']
                          model_instance.UCSH_105 = row['UCSH_105']
                          model_instance.UCSH_101_70 = row['UCSH_101_70']
                          model_instance.UCSH_102_70 = row['UCSH_102_70']
                          model_instance.UCSH_103_70 = row['UCSH_103_70']
                          model_instance.UCSH_104_70 = row['UCSH_104_70']
                          model_instance.UCSH_105_70 = row['UCSH_105_70']
                          model_instance.save()
            elif sheet_name == 'BbaOne':
                  for index,row in df[sheet_name].iterrows():
                        model_instance = BbaOne()
                        model_instance.Regdno = row['Regdno']
                        model_instance.Name = row['Name']
                        model_instance.Class = row['Class']
                        model_instance.UBBA_101 = row['UBBA_101']
                        model_instance.UBBA_102 = row['UBBA_102']
                        model_instance.UBBA_103 = row['UBBA_103']
                        model_instance.UBBA_104 = row['UBBA_104']
                        model_instance.UBBA_105 = row['UBBA_105']
                        model_instance.UBBA_101_70 = row['UBBA_101_70']
                        model_instance.UBBA_102_70 = row['UBBA_102_70']
                        model_instance.UBBA_103_70 = row['UBBA_103_70']
                        model_instance.UBBA_104_70 = row['UBBA_104_70']
                        model_instance.UBBA_105_70 = row['UBBA_105_70']
                        model_instance.save()
            elif sheet_name == 'SemesterTwo':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = SemesterTwo()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.UCSH_201 = row['UCSH_201']
                              model_instance.UCSH_202 = row['UCSH_202']
                              model_instance.UCSH_203 = row['UCSH_203']
                              model_instance.UCSH_204 = row['UCSH_204']
                              model_instance.UCSH_205 = row['UCSH_205']
                              model_instance.UCSH_201_70 = row['UCSH_201_70']
                              model_instance.UCSH_202_70 = row['UCSH_202_70']
                              model_instance.UCSH_203_70 = row['UCSH_203_70']
                              model_instance.UCSH_204_70 = row['UCSH_204_70']
                              model_instance.UCSH_205_70 = row['UCSH_205_70']
                              model_instance.save()
            elif sheet_name == 'SemesterThree':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = SemesterThree()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.UCSH_301 = row['UCSH_301']
                              model_instance.UCSH_302 = row['UCSH_302']
                              model_instance.UCSH_303 = row['UCSH_303']
                              model_instance.UCSH_304 = row['UCSH_304']
                              model_instance.UCSH_305 = row['UCSH_305']
                              model_instance.UCSH_301_70 = row['UCSH_301_70']
                              model_instance.UCSH_302_70 = row['UCSH_302_70']
                              model_instance.UCSH_303_70 = row['UCSH_303_70']
                              model_instance.UCSH_304_70 = row['UCSH_304_70']
                              model_instance.UCSH_305_70 = row['UCSH_305_70']
                              model_instance.save()
            elif sheet_name == 'SemesterFour':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = SemesterFour()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.UCSH_401 = row['UCSH_401']
                              model_instance.UCSH_402 = row['UCSH_402']
                              model_instance.UCSH_403 = row['UCSH_403']
                              model_instance.UCSH_404 = row['UCSH_404']
                              model_instance.UCSH_405 = row['UCSH_405']
                              model_instance.UCSH_401_70 = row['UCSH_401_70']
                              model_instance.UCSH_402_70 = row['UCSH_402_70']
                              model_instance.UCSH_403_70 = row['UCSH_403_70']
                              model_instance.UCSH_404_70 = row['UCSH_404_70']
                              model_instance.UCSH_405_70 = row['UCSH_405_70']
                              model_instance.save()
            elif sheet_name == 'Students':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = Students()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.UCSH_501 = row['UCSH_501']
                              model_instance.UCSH_502 = row['UCSH_502']
                              model_instance.UCSH_503 = row['UCSH_503']
                              model_instance.UCSH_504 = row['UCSH_504']
                              model_instance.UCSH_505 = row['UCSH_505']
                              model_instance.UCSH_501_70 = row['UCSH_501_70']
                              model_instance.UCSH_502_70 = row['UCSH_502_70']
                              model_instance.UCSH_503_70 = row['UCSH_503_70']
                              model_instance.UCSH_504_70 = row['UCSH_504_70']
                              model_instance.UCSH_505_70 = row['UCSH_505_70']
                              model_instance.save()
            elif sheet_name == 'SemesterSix':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = SemesterSix()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.UCSH_601 = row['UCSH_601']
                              model_instance.UCSH_602 = row['UCSH_602']
                              model_instance.UCSH_603 = row['UCSH_603']
                              model_instance.UCSH_604 = row['UCSH_604']
                              model_instance.UCSH_605 = row['UCSH_605']
                              model_instance.UCSH_601_70 = row['UCSH_601_70']
                              model_instance.UCSH_602_70 = row['UCSH_602_70']
                              model_instance.UCSH_603_70 = row['UCSH_603_70']
                              model_instance.UCSH_604_70 = row['UCSH_604_70']
                              model_instance.UCSH_605_70 = row['UCSH_605_70']
                              model_instance.save()
            elif sheet_name == 'MscOne':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = MscOne()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.MDSC_101 = row['MDSC_101']
                              model_instance.MDSC_102 = row['MDSC_102']
                              model_instance.MDSC_103 = row['MDSC_103']
                              model_instance.MDSC_104 = row['MDSC_104']
                              model_instance.MDSC_105 = row['MDSC_105']
                              model_instance.MDSC_101_70 = row['MDSC_101_70']
                              model_instance.MDSC_102_70 = row['MDSC_102_70']
                              model_instance.MDSC_103_70 = row['MDSC_103_70']
                              model_instance.MDSC_104_70 = row['MDSC_104_70']
                              model_instance.MDSC_105_70 = row['MDSC_105_70']
                              model_instance.save()
            elif sheet_name == 'MscTwo':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = MscTwo()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.MDSC_201 = row['MDSC_201']
                              model_instance.MDSC_202 = row['MDSC_202']
                              model_instance.MDSC_203 = row['MDSC_203']
                              model_instance.MDSC_204 = row['MDSC_204']
                              model_instance.MDSC_205 = row['MDSC_205']
                              model_instance.MDSC_201_70 = row['MDSC_201_70']
                              model_instance.MDSC_202_70 = row['MDSC_202_70']
                              model_instance.MDSC_203_70 = row['MDSC_203_70']
                              model_instance.MDSC_204_70 = row['MDSC_204_70']
                              model_instance.MDSC_205_70 = row['MDSC_205_70']
                              model_instance.save()
            elif sheet_name == 'MscThree':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = MscThree()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.MDSC_301 = row['MDSC_301']
                              model_instance.MDSC_302 = row['MDSC_302']
                              model_instance.MDSC_303 = row['MDSC_303']
                              model_instance.MDSC_304 = row['MDSC_304']
                              model_instance.MDSC_305 = row['MDSC_305']
                              model_instance.MDSC_301_70 = row['MDSC_301_70']
                              model_instance.MDSC_302_70 = row['MDSC_302_70']
                              model_instance.MDSC_303_70 = row['MDSC_303_70']
                              model_instance.MDSC_304_70 = row['MDSC_304_70']
                              model_instance.MDSC_305_70 = row['MDSC_305_70']
                              model_instance.save()
            elif sheet_name == 'MscFour':
                       for index, row in df[sheet_name].iterrows():
                              model_instance = MscFour()
                              model_instance.Regdno = row['Regdno']
                              model_instance.Name = row['Name']
                              model_instance.Class = row['Class']
                              model_instance.MDSC_401 = row['MDSC_401']
                              model_instance.MDSC_402 = row['MDSC_402']
                              model_instance.MDSC_403 = row['MDSC_403']
                              model_instance.MDSC_404 = row['MDSC_404']
                              model_instance.MDSC_405 = row['MDSC_405']
                              model_instance.MDSC_401_70 = row['MDSC_401_70']
                              model_instance.MDSC_402_70 = row['MDSC_402_70']
                              model_instance.MDSC_403_70 = row['MDSC_403_70']
                              model_instance.MDSC_404_70 = row['MDSC_404_70']
                              model_instance.MDSC_405_70 = row['MDSC_405_70']
                              model_instance.save()
            else:
                  return render(request, "Main/error.html",{})
         return render(request, "Main/Success.html", {})
      return render(request, "Main.upload_excel.html",{})
                             
def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return redirect("registersuccess")
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request=request, template_name="Main/register.html", context={"register_form":form})
'''
def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"You are now logged in as {username}.")
                if request.user == "warden":
                    pass
                else:
				    return redirect("homepage")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="Main/login.html", context={"login_form":form})
'''
def login_request(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                if request.user.is_superuser:
                    return redirect('admin:index')
                elif username == "warden":
                    return redirect('wardenhome')
                else:
                    return redirect("homepage")
            else:
                messages.error(request,"Invalid username or password.")
        else:
            messages.error(request,"Invalid username or password.")
    form = AuthenticationForm()
    return render(request=request, template_name="Main/login.html", context={"login_form":form})


def logout_request(request):
	logout(request)
	messages.info(request, "You have successfully logged out.") 
	return redirect("logoutpage")

'''
def logout_view(request):
    logout(request)
    response = redirect('login_request')
    response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response['Pragma'] = 'no-cache'
    response['Expires'] = '0'
    return response'''


def get_subject_codes_by_semester(semester):
    subject_codes_dict = {
        '1': ['UCSH-101', 'UCSH-102', 'UCSH-103', 'UCSH-104', 'UCSH-105','UCSH-101-70','UCSH-102-70','UCSH-103-70','USDH-104-70','UCSH-105-70'],
        '2': ['UCSH-201', 'UCSH-202', 'UCSH-203', 'UCSH-204', 'UCSH-205'],
        '3': ['UCSH-301', 'UCSH-302', 'UCSH-303', 'UCSH-304', 'UCSH-305'],
        '4': ['UCSH-401', 'UCSH-402', 'UCSH-403', 'UCSH-404', 'UCSH-405'],
        '5': ['UCSH-501', 'UCSH-502', 'UCSH-503', 'UCSH-504', 'UCSH-505'],
        '6': ['UCSH-601', 'UCSH-602', 'UCSH-603', 'UCSH-604', 'UCSH-605'],
        # Add more semester-subject code mappings as needed
    }

    return subject_codes_dict.get(semester, [])

'''
def update_subject_codes(request):
    semester = request.GET.get('semester')
    if semester:
        subject_codes = get_subject_codes_by_semester(semester)
        student_form = StuForm(subject_codes=subject_codes)
    else:
        student_form = None
    context = {
        'student_form': student_form,
    }
    return render(request, "Main/home.html", context)
'''

def semester_list(request):
        context = {
            'semesters': [
                {'class': 'I Bsc', 'semester': '1'},
                {'class': 'I Bsc', 'semester': '2'},
                {'class': 'I BBA', 'semester': '1'},
                {'class': 'I BBA', 'semester': '2'},
                {'class': 'II BSc', 'semester': '3'},
                {'class': 'II BSc', 'semester': '4'},
                {'class': 'II BBA', 'semester': '3'},
                {'class': 'II BBA', 'semester': '4'},
                {'class': 'III BSc', 'semester': '5'},
                {'class': 'III BSc', 'semester': '6'},
                {'class': 'III BBA', 'semester': '5'},
                {'class': 'III BBA', 'semester': '6'},

            ]
        }
        return render(request, 'Main/semester_list.html', context)

def student_form(request, semester):
    subject_codes = get_subject_codes_by_semester(semester)
    if request.method == 'POST':
        form = StuForm(request.POST, subject_codes=subject_codes)
        student = SemesterOne.objects.get(Regdno=request.POST.get('regdno'))
        if form.is_valid():
            # save form data to the database
            form.save()
            return redirect('semester_list')
    else:
        form = StuForm(subject_codes=subject_codes)
    context = {
        'semester': semester,
        'form': form,
    }
    return render(request, 'Main/student_form.html', context)