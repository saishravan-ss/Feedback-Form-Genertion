from django.urls import path
from django.views import View
from . import views

urlpatterns = [
    path("register/", views.register_request, name="register"),
    path("success/", views.registersuccess, name="registersuccess"),
    path("login/",views.login_request,name="login"),
    path("logout/",views.logout_request, name="logout"),
    path("",views.logoutpage,name="logoutpage"),
    path("home/",views.homepage,name="homepage"),
    path("input/", views.input,name="input"),
    path("upload/",views.upload_excel,name="upload_excel"),
    path("getresult/", views.get_result, name="getresult"),
    path("save/<str:Regdno>",views.save, name="save"),
    path("save/getresult/",views.get_result,name="get_result"),
    path("home/upload/",views.upload_excel,name="upload"),
    path("home/upload/home/",views.homepage,name="H"),
    path("home/input/",views.input,name="LI"),
    path("home/input/getresult/",views.get_result,name="LIG"),
    #path('update_subject_codes/', views.update_subject_codes, name='update_subject_codes'),
    path('semester/', views.semester_list, name='semester_list'),
    path('<str:semester>/', views.student_form, name='student_form'),
    path("oneinput/",views.oneinput,name="oneinput"),
    path("home/oneinput/",views.SemesterOne_Result,name="hoi"),
    path("twoinput/",views.twoinput,name="twoinput"),
    path("home/twoinput/",views.get_resulttwo,name="hti"),
    path("threeinput/",views.threeinput,name="threeinput"),
    path("home/threeinput/",views.get_resultthree,name="hthi"),
    path("fourinput/",views.fourinput,name="fourinput"),
    path("home/fourinput/",views.get_resultfour,name="hfi"),
    path("sixinput/",views.sixinput,name="sixinput"),
    path("home/sixinput/",views.get_resultsix,name="hsi"),
    path("foursave/<str:Regdno>",views.foursave,name="foursave"),
    path("onesave/<str:Regdno>/",views.onesave,name="onesave"),
    path("twosave/<str:Regdno>/",views.twosave,name="twosave"),
    path("threesave/<str:Regdno>/",views.threesave,name="threesave"),    
    path("sixsave/<str:Regdno>/",views.sixsave,name="sixsave"),  
    path("moneinput/",views.moneinput,name="moneinput"),  
    path("home/moneinput/",views.get_resultmone,name="hmoi"),
    path("msconesave/<str:Regdno>/",views.msconesave,name="mos"),
    path("msctwoinput/",views.msctwoinput,name="mti"),
    path("home/msctwoinput/",views.get_resultmtwo,name="mtr"),
    path("mscthreeinput/",views.mscthreeinput,name="mscthreeinput"),
    path("home/mscthreeinput/",views.get_resultmthree,name="mthr"),
    path("msctwosave/<str:Regdno>/",views.msctwosave,name="mts"),
    path("mscthreesave/<str:Regdno>/",views.mscthreesave,name="mths"),
    path("mscfourinput/",views.mscfourinput,name="mscfourinput"),
    path("home/mscfourinput/",views.get_resultmfour,name="mfr"),
    path("mscfoursave/<str:Regdno>/",views.mscfoursave,name="mfs"),

    path("bbaoneinput/",views.bbaoneinput,name="bbaoneinput"),
    path("home/bbaoneinput/",views.get_resultbbaone,name="bor"),
    path("bbaonesave/<str:Regdno>/",views.bbaonesave,name="bos"),
    path("bbatwoinput/",views.bbatwoinput,name="bbatwoinput"),
    path("home/bbatwoinput/",views.get_resultbbatwo,name="btr"),

    path("bbathreeinput/",views.bbathreeinput,name="bbathreeinput"),
    path("home/bbathreeinput/",views.get_resultbbathree,name="bthr"),

    path("bbafiveinput/",views.bbafiveinput,name="bbafiveinput"),
    path("home/bbafiveinput/",views.get_resultbbafive,name="bfr"),



    
]